CREATE FUNCTION scout_ask_players_params_for_matches_table () RETURNS json
	LANGUAGE plpgsql
AS $$
BEGIN

RETURN (
WITH params AS (
	SELECT
		sp.f_ttd_stat_param_player as param_id
		,sp.f_ttd_stat_param_option as option_id
		,sp.name as param_name
		,sp.lexical_formula as lexica
		,sp.lexical_formula_short as lexica_short
		,sp.c_scout_player_param_group as param_group
		,pg.name as param_group_name
		,sp.default_at_params_table as default
		,CASE WHEN sp0.c_ttd_stat_calc_method = 2 THEN trim(sp0.formula) END as formula
		,CASE WHEN sp0.c_ttd_stat_calc_method = 2 THEN 0 ELSE 1 END AS clickable
	FROM
		f_scout_player_params sp
		JOIN f_ttd_stat_param_player sp0
			ON sp0.id = sp.f_ttd_stat_param_player
		JOIN c_scout_player_param_group pg
			ON pg.id = sp.c_scout_player_param_group
)
SELECT
	array_to_json(array_agg(row_to_json(t)))
FROM
	(
		SELECT
			p.param_group,
			p.param_group_name,
			CASE
				WHEN p.param_group = 1 THEN 2929
				WHEN p.param_group = 2 THEN 412
				WHEN p.param_group = 3 THEN 3604
				WHEN p.param_group = 4 THEN 4120
				WHEN p.param_group = 5 THEN 3602
			END as lexica,
			(
				SELECT array_to_json(array_agg(row_to_json(d)))
				FROM
					(
						SELECT
							p1.param_id,
							p1.option_id,
							p1.param_name,
							p1.lexica,
							p1.lexica_short,
							p1.formula,
							p1.default,
							p1.clickable
						FROM
							params p1
						WHERE
							p1.param_group = p.param_group
					) d
			) AS params
		FROM
			params p
		GROUP BY p.param_group, p.param_group_name
	) t
);

END

$$
